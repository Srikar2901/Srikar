import os, secrets
from datetime import datetime, timezone
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify, abort
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY") or secrets.token_hex(32)
db_url = os.environ.get("DATABASE_URL", "sqlite:///aquamonitor.db")
if db_url.startswith("postgres://"):
    db_url = db_url.replace("postgres://", "postgresql://", 1)
app.config["SQLALCHEMY_DATABASE_URI"] = db_url
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
app.config["SESSION_COOKIE_SECURE"] = os.environ.get("RENDER") == "true"
db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(180), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), default="user", nullable=False) # superadmin/admin/user
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))

class Station(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(40), unique=True, nullable=False)
    name = db.Column(db.String(140), nullable=False)
    kind = db.Column(db.String(20), default="community") # community/household
    address = db.Column(db.String(240), default="")
    house_owner = db.Column(db.String(140), default="")
    owner_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=True)
    sensor_key = db.Column(db.String(80), unique=True, nullable=False)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))
    owner = db.relationship("User", foreign_keys=[owner_id])

class Reading(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    station_id = db.Column(db.Integer, db.ForeignKey("station.id"), nullable=False, index=True)
    ph = db.Column(db.Float, nullable=False)
    turbidity = db.Column(db.Float, nullable=False)
    temperature = db.Column(db.Float, nullable=False)
    dissolved_oxygen = db.Column(db.Float, nullable=False)
    tds = db.Column(db.Float, nullable=False)
    conductivity = db.Column(db.Float, default=0)
    wqi = db.Column(db.Integer, nullable=False)
    status = db.Column(db.String(20), nullable=False)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), index=True)
    station = db.relationship("Station", backref=db.backref("readings", lazy=True, cascade="all, delete-orphan"))

class Alert(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    station_id = db.Column(db.Integer, db.ForeignKey("station.id"), nullable=False)
    message = db.Column(db.String(300), nullable=False)
    severity = db.Column(db.String(20), nullable=False)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))
    station = db.relationship("Station")

def current_user():
    uid = session.get("uid")
    return db.session.get(User, uid) if uid else None

def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not current_user():
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapper

def admin_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        u = current_user()
        if not u:
            return redirect(url_for("login"))
        if u.role not in ("superadmin", "admin"):
            abort(403)
        return fn(*args, **kwargs)
    return wrapper

def wqi_score(ph, turbidity, temperature, oxygen, tds):
    # Transparent demonstration score; not a certified regulatory WQI calculation.
    score = 100
    if ph < 6.5 or ph > 8.5: score -= min(30, abs(ph - 7.5) * 12)
    if turbidity > 5: score -= min(25, (turbidity - 5) * 0.5)
    if tds > 500: score -= min(25, (tds - 500) / 40)
    if oxygen < 6: score -= min(20, (6 - oxygen) * 5)
    if temperature < 10 or temperature > 35: score -= 10
    return max(0, min(100, round(score)))

def quality_status(score):
    return "Safe" if score >= 70 else ("Caution" if score >= 50 else "Unsafe")

def visible_stations(user):
    q = Station.query
    if user.role == "superadmin":
        return q.order_by(Station.created_at.desc()).all()
    if user.role == "admin":
        return q.order_by(Station.created_at.desc()).all()
    return q.filter((Station.owner_id == user.id) | (Station.kind == "community")).order_by(Station.created_at.desc()).all()

@app.context_processor
def inject_user():
    return {"me": current_user()}

@app.route("/")
def index():
    if not current_user(): return redirect(url_for("login"))
    return redirect(url_for("dashboard"))

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name, email = request.form.get("name","").strip(), request.form.get("email","").strip().lower()
        password = request.form.get("password","")
        if not name or not email or len(password) < 8:
            flash("Enter your name, a valid email and a password of at least 8 characters.", "error")
        elif User.query.filter_by(email=email).first():
            flash("That email is already registered.", "error")
        else:
            u = User(name=name, email=email, password_hash=generate_password_hash(password))
            db.session.add(u); db.session.commit()
            session["uid"] = u.id
            flash("Account created. You can now register your household.", "success")
            return redirect(url_for("dashboard"))
    return render_template("auth.html", mode="register")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        u = User.query.filter_by(email=request.form.get("email","").strip().lower()).first()
        if u and check_password_hash(u.password_hash, request.form.get("password","")):
            session.clear(); session["uid"] = u.id
            return redirect(url_for("dashboard"))
        flash("Incorrect email or password.", "error")
    return render_template("auth.html", mode="login")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.route("/dashboard")
@login_required
def dashboard():
    u = current_user()
    stations = visible_stations(u)
    station_ids = [s.id for s in stations]
    latest = []
    for s in stations:
        r = Reading.query.filter_by(station_id=s.id).order_by(Reading.created_at.desc()).first()
        if r: latest.append(r)
    alerts = Alert.query.filter(Alert.station_id.in_(station_ids)).order_by(Alert.created_at.desc()).limit(8).all() if station_ids else []
    avg = round(sum(r.wqi for r in latest)/len(latest)) if latest else None
    return render_template("dashboard.html", stations=stations, latest=latest, alerts=alerts, avg=avg,
                           total_houses=sum(1 for s in stations if s.kind=="household"),
                           total_community=sum(1 for s in stations if s.kind=="community"))

@app.route("/stations")
@login_required
def stations():
    return render_template("stations.html", stations=visible_stations(current_user()))

@app.route("/stations/add", methods=["POST"])
@admin_required
def add_station():
    code = request.form.get("code","").strip().upper()
    if not code or Station.query.filter_by(code=code).first():
        flash("Station ID is required and must be unique.", "error"); return redirect(url_for("stations"))
    kind = request.form.get("kind","community")
    if kind not in ("community","household"): kind="community"
    owner_id = request.form.get("owner_id") or None
    if owner_id:
        owner_id = int(owner_id)
    s = Station(code=code, name=request.form.get("name","").strip(), kind=kind,
                address=request.form.get("address","").strip(), house_owner=request.form.get("house_owner","").strip(),
                owner_id=owner_id, sensor_key=secrets.token_urlsafe(32))
    db.session.add(s); db.session.commit()
    flash(f"Station created. Sensor API key: {s.sensor_key} — copy it now and keep it private.", "success")
    return redirect(url_for("stations"))

@app.route("/stations/<int:sid>/delete", methods=["POST"])
@admin_required
def delete_station(sid):
    s = db.session.get(Station, sid)
    if s: db.session.delete(s); db.session.commit(); flash("Station removed.", "success")
    return redirect(url_for("stations"))

@app.route("/readings/add", methods=["POST"])
@login_required
def add_reading():
    u = current_user()
    try:
        sid = int(request.form["station_id"])
        s = db.session.get(Station, sid)
        if not s: abort(404)
        if u.role not in ("superadmin","admin") and s.owner_id != u.id: abort(403)
        vals = [float(request.form[k]) for k in ("ph","turbidity","temperature","dissolved_oxygen","tds")]
        conductivity = float(request.form.get("conductivity") or 0)
        ph,turb,temp,oxy,tds = vals
        if not (0 <= ph <= 14 and 0 <= turb <= 5000 and -5 <= temp <= 100 and 0 <= oxy <= 50 and 0 <= tds <= 100000):
            raise ValueError()
        score = wqi_score(ph,turb,temp,oxy,tds); status = quality_status(score)
        r = Reading(station_id=sid, ph=ph, turbidity=turb, temperature=temp, dissolved_oxygen=oxy, tds=tds,
                    conductivity=conductivity, wqi=score, status=status)
        db.session.add(r)
        if status != "Safe":
            db.session.add(Alert(station_id=sid, message=f"{s.name}: reading classified as {status} (WQI {score}).", severity="critical" if status=="Unsafe" else "warning"))
        db.session.commit()
        flash("Water reading saved.", "success")
    except (KeyError, ValueError):
        flash("Check that all sensor values are valid numbers.", "error")
    return redirect(url_for("dashboard"))

@app.route("/api/sensor/<code>", methods=["POST"])
def sensor_ingest(code):
    s = Station.query.filter_by(code=code.upper()).first_or_404()
    if not secrets.compare_digest(request.headers.get("X-API-Key",""), s.sensor_key):
        return jsonify(error="Unauthorized"), 401
    data = request.get_json(silent=True) or {}
    try:
        ph=float(data["ph"]); turb=float(data["turbidity"]); temp=float(data["temperature"])
        oxy=float(data["dissolved_oxygen"]); tds=float(data["tds"]); cond=float(data.get("conductivity",0))
        if not (0 <= ph <= 14 and turb >= 0 and -5 <= temp <= 100 and oxy >= 0 and tds >= 0): raise ValueError()
    except (KeyError, TypeError, ValueError):
        return jsonify(error="Required numeric fields: ph, turbidity, temperature, dissolved_oxygen, tds"), 400
    score=wqi_score(ph,turb,temp,oxy,tds); status=quality_status(score)
    r=Reading(station_id=s.id,ph=ph,turbidity=turb,temperature=temp,dissolved_oxygen=oxy,tds=tds,conductivity=cond,wqi=score,status=status)
    db.session.add(r)
    if status!="Safe": db.session.add(Alert(station_id=s.id,message=f"{s.name}: {status} water reading (WQI {score}).",severity="critical" if status=="Unsafe" else "warning"))
    db.session.commit()
    return jsonify(ok=True, station=s.code, wqi=score, status=status), 201

@app.route("/users")
@admin_required
def users():
    return render_template("users.html", users=User.query.order_by(User.created_at.desc()).all())

@app.route("/users/<int:uid>/role", methods=["POST"])
@admin_required
def change_role(uid):
    u = db.session.get(User, uid)
    if not u: abort(404)
    if u.id == current_user().id: flash("You cannot change your own role here.", "error")
    elif u.role == "superadmin": flash("The Super Admin role is protected.", "error")
    else:
        role=request.form.get("role")
        if role in ("user","admin"): u.role=role; db.session.commit(); flash("User role updated.", "success")
    return redirect(url_for("users"))

@app.route("/reports")
@login_required
def reports():
    u=current_user(); stations=visible_stations(u); ids=[s.id for s in stations]
    readings=Reading.query.filter(Reading.station_id.in_(ids)).order_by(Reading.created_at.desc()).limit(200).all() if ids else []
    return render_template("reports.html", readings=readings)

@app.route("/health")
def health():
    return {"status":"ok","service":"AquaMonitor Pro"}

with app.app_context():
    db.create_all()
    # The first account configured through Render environment variables becomes the permanent Super Admin.
    admin_email=os.environ.get("ADMIN_EMAIL","").strip().lower()
    admin_password=os.environ.get("ADMIN_PASSWORD","")
    if admin_email and admin_password and not User.query.filter_by(role="superadmin").first():
        existing=User.query.filter_by(email=admin_email).first()
        if existing:
            existing.role="superadmin"
        else:
            db.session.add(User(name=os.environ.get("ADMIN_NAME","Site Owner"),email=admin_email,
                                password_hash=generate_password_hash(admin_password),role="superadmin"))
        db.session.commit()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 10000)), debug=False)
