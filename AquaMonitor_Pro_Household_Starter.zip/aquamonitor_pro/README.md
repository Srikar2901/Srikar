# AquaMonitor Pro — Community + Household Edition

A Flask/PostgreSQL water-quality monitoring starter with household-level stations, role-based access, manual readings, alerts, reports, and an ESP32 ingestion API.

## Local run
1. Install Python 3.11+.
2. `python -m venv .venv`
3. Activate it, then `pip install -r requirements.txt`
4. Set `ADMIN_EMAIL`, `ADMIN_PASSWORD` (minimum 12 characters), and `SECRET_KEY`.
5. `python app.py` then open http://127.0.0.1:10000

For local development, SQLite is used if `DATABASE_URL` is not set.

## Render deployment
1. Create a GitHub repository and upload this project.
2. In Render, choose **New → Blueprint**, connect the repository, and review `render.yaml`.
3. Set `ADMIN_EMAIL` and a strong unique `ADMIN_PASSWORD` when prompted.
4. Deploy. The Blueprint creates a web service and managed PostgreSQL database.
5. Open the service URL and sign in using the configured admin credentials.

Do not put real passwords or API keys in GitHub. Configure them only in Render Environment.

## Household workflow
- Admin creates a station with type `Household`, address and household owner.
- Optionally associate it with a registered user using the user's numeric ID from User Management.
- The resident can see their own household station and community stations.
- Admin can add readings manually; residents can add readings only for their own household station.
- Each station has a private sensor API key. Copy it when creating the station; the UI displays it once in a flash message.

## ESP32 sensor API
`POST /api/sensor/STATION_CODE`

Headers:
`Content-Type: application/json`
`X-API-Key: YOUR_STATION_SENSOR_KEY`

JSON:
```json
{
  "ph": 7.2,
  "turbidity": 1.8,
  "temperature": 27.5,
  "dissolved_oxygen": 7.1,
  "tds": 240,
  "conductivity": 380
}
```

The API returns the calculated demonstration WQI and status. Protect each key and do not expose it in firmware repositories.

## Important water-safety note
The included WQI formula is a transparent demonstration score, not an official CPCB/BIS/WHO compliance calculation. Sensor readings and status labels are informational and must not be used alone to declare drinking water safe. Calibrate sensors and confirm drinking-water compliance with an accredited laboratory against applicable BIS IS 10500 requirements.

## Current MVP boundaries
Email/SMS delivery, password reset, downloadable PDF reports, map tiles, multi-factor authentication, audit log, and advanced charting are not yet implemented. The Reports page currently shows saved readings in a printable table.
